package com.baeldung.taskmanagementapplesson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagementAppLessonApplicationTests {

	@Test
	void contextLoads() {
	}

}
